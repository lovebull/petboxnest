--
-- PostgreSQL database dump
--

\restrict navkdlxEfgIhZcDjBJ1lgHUDBzky7B6f5k9vm3nXc9qN2jq7ecMlyw3Z5iOZaQO

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.users_sessions DROP CONSTRAINT users_sessions_parent_id_fk;
ALTER TABLE ONLY public.product_enhancements_story_sections DROP CONSTRAINT product_enhancements_story_sections_parent_id_fk;
ALTER TABLE ONLY public.product_enhancements_story_sections DROP CONSTRAINT product_enhancements_story_sections_image_id_media_id_fk;
ALTER TABLE ONLY public.product_enhancements_specifications DROP CONSTRAINT product_enhancements_specifications_parent_id_fk;
ALTER TABLE ONLY public.product_enhancements DROP CONSTRAINT product_enhancements_seo_og_image_id_media_id_fk;
ALTER TABLE ONLY public.product_enhancements_image_blocks DROP CONSTRAINT product_enhancements_image_blocks_parent_id_fk;
ALTER TABLE ONLY public.product_enhancements_image_blocks DROP CONSTRAINT product_enhancements_image_blocks_image_id_media_id_fk;
ALTER TABLE ONLY public.product_enhancements_highlights DROP CONSTRAINT product_enhancements_highlights_parent_id_fk;
ALTER TABLE ONLY public.payload_preferences_rels DROP CONSTRAINT payload_preferences_rels_users_fk;
ALTER TABLE ONLY public.payload_preferences_rels DROP CONSTRAINT payload_preferences_rels_parent_fk;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_users_fk;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_product_enhancements_fk;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_parent_fk;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_online_images_fk;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_media_fk;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_articles_fk;
ALTER TABLE ONLY public.articles DROP CONSTRAINT articles_seo_og_image_id_media_id_fk;
ALTER TABLE ONLY public.articles_rels DROP CONSTRAINT articles_rels_product_enhancements_fk;
ALTER TABLE ONLY public.articles_rels DROP CONSTRAINT articles_rels_parent_fk;
ALTER TABLE ONLY public.articles DROP CONSTRAINT articles_hero_image_id_media_id_fk;
DROP INDEX public.users_updated_at_idx;
DROP INDEX public.users_sessions_parent_id_idx;
DROP INDEX public.users_sessions_order_idx;
DROP INDEX public.users_email_idx;
DROP INDEX public.users_created_at_idx;
DROP INDEX public.product_enhancements_updated_at_idx;
DROP INDEX public.product_enhancements_story_sections_parent_id_idx;
DROP INDEX public.product_enhancements_story_sections_order_idx;
DROP INDEX public.product_enhancements_story_sections_image_idx;
DROP INDEX public.product_enhancements_specifications_parent_id_idx;
DROP INDEX public.product_enhancements_specifications_order_idx;
DROP INDEX public.product_enhancements_seo_seo_og_image_idx;
DROP INDEX public.product_enhancements_medusa_product_id_idx;
DROP INDEX public.product_enhancements_medusa_product_handle_idx;
DROP INDEX public.product_enhancements_image_blocks_parent_id_idx;
DROP INDEX public.product_enhancements_image_blocks_order_idx;
DROP INDEX public.product_enhancements_image_blocks_image_idx;
DROP INDEX public.product_enhancements_highlights_parent_id_idx;
DROP INDEX public.product_enhancements_highlights_order_idx;
DROP INDEX public.product_enhancements_created_at_idx;
DROP INDEX public.payload_preferences_updated_at_idx;
DROP INDEX public.payload_preferences_rels_users_id_idx;
DROP INDEX public.payload_preferences_rels_path_idx;
DROP INDEX public.payload_preferences_rels_parent_idx;
DROP INDEX public.payload_preferences_rels_order_idx;
DROP INDEX public.payload_preferences_key_idx;
DROP INDEX public.payload_preferences_created_at_idx;
DROP INDEX public.payload_migrations_updated_at_idx;
DROP INDEX public.payload_migrations_created_at_idx;
DROP INDEX public.payload_locked_documents_updated_at_idx;
DROP INDEX public.payload_locked_documents_rels_users_id_idx;
DROP INDEX public.payload_locked_documents_rels_product_enhancements_id_idx;
DROP INDEX public.payload_locked_documents_rels_path_idx;
DROP INDEX public.payload_locked_documents_rels_parent_idx;
DROP INDEX public.payload_locked_documents_rels_order_idx;
DROP INDEX public.payload_locked_documents_rels_online_images_id_idx;
DROP INDEX public.payload_locked_documents_rels_media_id_idx;
DROP INDEX public.payload_locked_documents_rels_articles_id_idx;
DROP INDEX public.payload_locked_documents_global_slug_idx;
DROP INDEX public.payload_locked_documents_created_at_idx;
DROP INDEX public.payload_kv_key_idx;
DROP INDEX public.online_images_updated_at_idx;
DROP INDEX public.online_images_created_at_idx;
DROP INDEX public.media_updated_at_idx;
DROP INDEX public.media_sizes_thumbnail_sizes_thumbnail_filename_idx;
DROP INDEX public.media_sizes_product_story_sizes_product_story_filename_idx;
DROP INDEX public.media_filename_idx;
DROP INDEX public.media_created_at_idx;
DROP INDEX public.articles_updated_at_idx;
DROP INDEX public.articles_slug_idx;
DROP INDEX public.articles_seo_seo_og_image_idx;
DROP INDEX public.articles_rels_product_enhancements_id_idx;
DROP INDEX public.articles_rels_path_idx;
DROP INDEX public.articles_rels_parent_idx;
DROP INDEX public.articles_rels_order_idx;
DROP INDEX public.articles_hero_image_idx;
DROP INDEX public.articles_created_at_idx;
ALTER TABLE ONLY public.users_sessions DROP CONSTRAINT users_sessions_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.product_enhancements_story_sections DROP CONSTRAINT product_enhancements_story_sections_pkey;
ALTER TABLE ONLY public.product_enhancements_specifications DROP CONSTRAINT product_enhancements_specifications_pkey;
ALTER TABLE ONLY public.product_enhancements DROP CONSTRAINT product_enhancements_pkey;
ALTER TABLE ONLY public.product_enhancements_image_blocks DROP CONSTRAINT product_enhancements_image_blocks_pkey;
ALTER TABLE ONLY public.product_enhancements_highlights DROP CONSTRAINT product_enhancements_highlights_pkey;
ALTER TABLE ONLY public.payload_preferences_rels DROP CONSTRAINT payload_preferences_rels_pkey;
ALTER TABLE ONLY public.payload_preferences DROP CONSTRAINT payload_preferences_pkey;
ALTER TABLE ONLY public.payload_migrations DROP CONSTRAINT payload_migrations_pkey;
ALTER TABLE ONLY public.payload_locked_documents_rels DROP CONSTRAINT payload_locked_documents_rels_pkey;
ALTER TABLE ONLY public.payload_locked_documents DROP CONSTRAINT payload_locked_documents_pkey;
ALTER TABLE ONLY public.payload_kv DROP CONSTRAINT payload_kv_pkey;
ALTER TABLE ONLY public.online_images DROP CONSTRAINT online_images_pkey;
ALTER TABLE ONLY public.media DROP CONSTRAINT media_pkey;
ALTER TABLE ONLY public.articles_rels DROP CONSTRAINT articles_rels_pkey;
ALTER TABLE ONLY public.articles DROP CONSTRAINT articles_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.product_enhancements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.payload_preferences_rels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.payload_preferences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.payload_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.payload_locked_documents_rels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.payload_locked_documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.payload_kv ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.online_images ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.media ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.articles_rels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.articles ALTER COLUMN id DROP DEFAULT;
DROP TABLE public.users_sessions;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.product_enhancements_story_sections;
DROP TABLE public.product_enhancements_specifications;
DROP TABLE public.product_enhancements_image_blocks;
DROP SEQUENCE public.product_enhancements_id_seq;
DROP TABLE public.product_enhancements_highlights;
DROP TABLE public.product_enhancements;
DROP SEQUENCE public.payload_preferences_rels_id_seq;
DROP TABLE public.payload_preferences_rels;
DROP SEQUENCE public.payload_preferences_id_seq;
DROP TABLE public.payload_preferences;
DROP SEQUENCE public.payload_migrations_id_seq;
DROP TABLE public.payload_migrations;
DROP SEQUENCE public.payload_locked_documents_rels_id_seq;
DROP TABLE public.payload_locked_documents_rels;
DROP SEQUENCE public.payload_locked_documents_id_seq;
DROP TABLE public.payload_locked_documents;
DROP SEQUENCE public.payload_kv_id_seq;
DROP TABLE public.payload_kv;
DROP SEQUENCE public.online_images_id_seq;
DROP TABLE public.online_images;
DROP SEQUENCE public.media_id_seq;
DROP TABLE public.media;
DROP SEQUENCE public.articles_rels_id_seq;
DROP TABLE public.articles_rels;
DROP SEQUENCE public.articles_id_seq;
DROP TABLE public.articles;
DROP TYPE public.enum_product_enhancements_story_sections_image_position;
DROP TYPE public.enum_product_enhancements_status;
DROP TYPE public.enum_articles_status;
--
-- Name: enum_articles_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_articles_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_articles_status OWNER TO postgres;

--
-- Name: enum_product_enhancements_status; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_product_enhancements_status AS ENUM (
    'draft',
    'published'
);


ALTER TYPE public.enum_product_enhancements_status OWNER TO postgres;

--
-- Name: enum_product_enhancements_story_sections_image_position; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.enum_product_enhancements_story_sections_image_position AS ENUM (
    'left',
    'right'
);


ALTER TYPE public.enum_product_enhancements_story_sections_image_position OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    status public.enum_articles_status DEFAULT 'draft'::public.enum_articles_status NOT NULL,
    title character varying NOT NULL,
    slug character varying NOT NULL,
    excerpt character varying,
    hero_image_id integer,
    content jsonb NOT NULL,
    published_at timestamp(3) with time zone,
    seo_meta_title character varying,
    seo_meta_description character varying,
    seo_og_image_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    hero_image_url character varying
);


ALTER TABLE public.articles OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: articles_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articles_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    product_enhancements_id integer
);


ALTER TABLE public.articles_rels OWNER TO postgres;

--
-- Name: articles_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articles_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_rels_id_seq OWNER TO postgres;

--
-- Name: articles_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articles_rels_id_seq OWNED BY public.articles_rels.id;


--
-- Name: media; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media (
    id integer NOT NULL,
    alt character varying NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    url character varying,
    thumbnail_u_r_l character varying,
    filename character varying,
    mime_type character varying,
    filesize numeric,
    width numeric,
    height numeric,
    focal_x numeric,
    focal_y numeric,
    sizes_thumbnail_url character varying,
    sizes_thumbnail_width numeric,
    sizes_thumbnail_height numeric,
    sizes_thumbnail_mime_type character varying,
    sizes_thumbnail_filesize numeric,
    sizes_thumbnail_filename character varying,
    sizes_product_story_url character varying,
    sizes_product_story_width numeric,
    sizes_product_story_height numeric,
    sizes_product_story_mime_type character varying,
    sizes_product_story_filesize numeric,
    sizes_product_story_filename character varying
);


ALTER TABLE public.media OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.media_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.media_id_seq OWNER TO postgres;

--
-- Name: media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.media_id_seq OWNED BY public.media.id;


--
-- Name: online_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.online_images (
    id integer NOT NULL,
    title character varying NOT NULL,
    image_url character varying NOT NULL,
    description character varying,
    alt character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.online_images OWNER TO postgres;

--
-- Name: online_images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.online_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.online_images_id_seq OWNER TO postgres;

--
-- Name: online_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.online_images_id_seq OWNED BY public.online_images.id;


--
-- Name: payload_kv; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_kv (
    id integer NOT NULL,
    key character varying NOT NULL,
    data jsonb NOT NULL
);


ALTER TABLE public.payload_kv OWNER TO postgres;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_kv_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_kv_id_seq OWNER TO postgres;

--
-- Name: payload_kv_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_kv_id_seq OWNED BY public.payload_kv.id;


--
-- Name: payload_locked_documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_locked_documents (
    id integer NOT NULL,
    global_slug character varying,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_locked_documents OWNER TO postgres;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_locked_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_id_seq OWNER TO postgres;

--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_locked_documents_id_seq OWNED BY public.payload_locked_documents.id;


--
-- Name: payload_locked_documents_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_locked_documents_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer,
    media_id integer,
    product_enhancements_id integer,
    articles_id integer,
    online_images_id integer
);


ALTER TABLE public.payload_locked_documents_rels OWNER TO postgres;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_locked_documents_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNER TO postgres;

--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_locked_documents_rels_id_seq OWNED BY public.payload_locked_documents_rels.id;


--
-- Name: payload_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_migrations (
    id integer NOT NULL,
    name character varying,
    batch numeric,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_migrations OWNER TO postgres;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_migrations_id_seq OWNER TO postgres;

--
-- Name: payload_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_migrations_id_seq OWNED BY public.payload_migrations.id;


--
-- Name: payload_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_preferences (
    id integer NOT NULL,
    key character varying,
    value jsonb,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.payload_preferences OWNER TO postgres;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_id_seq OWNER TO postgres;

--
-- Name: payload_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_preferences_id_seq OWNED BY public.payload_preferences.id;


--
-- Name: payload_preferences_rels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payload_preferences_rels (
    id integer NOT NULL,
    "order" integer,
    parent_id integer NOT NULL,
    path character varying NOT NULL,
    users_id integer
);


ALTER TABLE public.payload_preferences_rels OWNER TO postgres;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payload_preferences_rels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNER TO postgres;

--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payload_preferences_rels_id_seq OWNED BY public.payload_preferences_rels.id;


--
-- Name: product_enhancements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_enhancements (
    id integer NOT NULL,
    status public.enum_product_enhancements_status DEFAULT 'draft'::public.enum_product_enhancements_status NOT NULL,
    medusa_product_id character varying,
    medusa_product_handle character varying NOT NULL,
    title character varying NOT NULL,
    subtitle character varying,
    hero_eyebrow character varying,
    care_notes character varying,
    video_url character varying,
    seo_meta_title character varying,
    seo_meta_description character varying,
    seo_og_image_id integer,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    content jsonb
);


ALTER TABLE public.product_enhancements OWNER TO postgres;

--
-- Name: product_enhancements_highlights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_enhancements_highlights (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    label character varying,
    description character varying
);


ALTER TABLE public.product_enhancements_highlights OWNER TO postgres;

--
-- Name: product_enhancements_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_enhancements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_enhancements_id_seq OWNER TO postgres;

--
-- Name: product_enhancements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_enhancements_id_seq OWNED BY public.product_enhancements.id;


--
-- Name: product_enhancements_image_blocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_enhancements_image_blocks (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    image_id integer,
    title character varying,
    description character varying
);


ALTER TABLE public.product_enhancements_image_blocks OWNER TO postgres;

--
-- Name: product_enhancements_specifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_enhancements_specifications (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    label character varying NOT NULL,
    value character varying NOT NULL
);


ALTER TABLE public.product_enhancements_specifications OWNER TO postgres;

--
-- Name: product_enhancements_story_sections; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_enhancements_story_sections (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    heading character varying,
    body character varying,
    image_id integer,
    image_position public.enum_product_enhancements_story_sections_image_position DEFAULT 'left'::public.enum_product_enhancements_story_sections_image_position
);


ALTER TABLE public.product_enhancements_story_sections OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    updated_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    created_at timestamp(3) with time zone DEFAULT now() NOT NULL,
    email character varying NOT NULL,
    reset_password_token character varying,
    reset_password_expiration timestamp(3) with time zone,
    salt character varying,
    hash character varying,
    login_attempts numeric DEFAULT 0,
    lock_until timestamp(3) with time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_sessions (
    _order integer NOT NULL,
    _parent_id integer NOT NULL,
    id character varying NOT NULL,
    created_at timestamp(3) with time zone,
    expires_at timestamp(3) with time zone NOT NULL
);


ALTER TABLE public.users_sessions OWNER TO postgres;

--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: articles_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles_rels ALTER COLUMN id SET DEFAULT nextval('public.articles_rels_id_seq'::regclass);


--
-- Name: media id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media ALTER COLUMN id SET DEFAULT nextval('public.media_id_seq'::regclass);


--
-- Name: online_images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.online_images ALTER COLUMN id SET DEFAULT nextval('public.online_images_id_seq'::regclass);


--
-- Name: payload_kv id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_kv ALTER COLUMN id SET DEFAULT nextval('public.payload_kv_id_seq'::regclass);


--
-- Name: payload_locked_documents id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_id_seq'::regclass);


--
-- Name: payload_locked_documents_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_locked_documents_rels_id_seq'::regclass);


--
-- Name: payload_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_migrations ALTER COLUMN id SET DEFAULT nextval('public.payload_migrations_id_seq'::regclass);


--
-- Name: payload_preferences id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_id_seq'::regclass);


--
-- Name: payload_preferences_rels id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels ALTER COLUMN id SET DEFAULT nextval('public.payload_preferences_rels_id_seq'::regclass);


--
-- Name: product_enhancements id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements ALTER COLUMN id SET DEFAULT nextval('public.product_enhancements_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles (id, status, title, slug, excerpt, hero_image_id, content, published_at, seo_meta_title, seo_meta_description, seo_og_image_id, updated_at, created_at, hero_image_url) FROM stdin;
1	published	测试1	test	ces测猜测	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h3", "type": "heading", "format": "start", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Hour of Leisure, Edition 02", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}], "direction": null}}	2026-08-12 12:00:00-04	\N	\N	\N	2026-08-13 08:10:15.177-04	2026-08-13 08:10:15.159-04	https://picsum.photos/900/560?random=41
2	published	测序2	test2	ssss山啥事	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"tag": "h3", "type": "heading", "format": "start", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Behind the Collection: Meet the Standards", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}], "direction": null}}	2026-08-12 12:00:00-04	\N	\N	\N	2026-08-13 08:10:57.923-04	2026-08-13 08:10:57.92-04	https://picsum.photos/900/560?random=42
3	published	测试3	test3	测试Where to Play Pickleball This Summer	\N	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "h3", "type": "heading", "format": "start", "indent": 0, "version": 1, "children": [{"id": "6a7db472a9ce7c6084c9868a", "type": "link", "fields": {"url": "http://203.88.118.104:8010/us/store", "newTab": false, "linkType": "custom"}, "format": "", "indent": 0, "version": 3, "children": [{"mode": "normal", "text": "Where to Play Pickleball This Summer", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}], "direction": null}], "direction": null}}	2026-08-12 12:00:00-04	\N	\N	\N	2026-08-13 21:07:41.651-04	2026-08-13 08:11:35.543-04	https://picsum.photos/900/560?random=43
\.


--
-- Data for Name: articles_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articles_rels (id, "order", parent_id, path, product_enhancements_id) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media (id, alt, updated_at, created_at, url, thumbnail_u_r_l, filename, mime_type, filesize, width, height, focal_x, focal_y, sizes_thumbnail_url, sizes_thumbnail_width, sizes_thumbnail_height, sizes_thumbnail_mime_type, sizes_thumbnail_filesize, sizes_thumbnail_filename, sizes_product_story_url, sizes_product_story_width, sizes_product_story_height, sizes_product_story_mime_type, sizes_product_story_filesize, sizes_product_story_filename) FROM stdin;
1	Badminton Shuttlecocks	2026-08-24 13:04:58.089-04	2026-08-24 13:04:58.057-04	https://cdn.larumsport.com/media/e5abfa42-a098-47f9-9c32-5c62348a84be.__CR0%2C0%2C970%2C600_PT0_SX970_V1___.jpg	\N	https://cdn.larumsport.com/media/e5abfa42-a098-47f9-9c32-5c62348a84be.__CR0,0,970,600_PT0_SX970_V1___.jpg	image/jpeg	179219	970	600	50	50	/api/media/file/e5abfa42-a098-47f9-9c32-5c62348a84be.__CR0%2C0%2C970%2C600_PT0_SX970_V1___-400x300.jpg	400	300	image/jpeg	45620	e5abfa42-a098-47f9-9c32-5c62348a84be.__CR0,0,970,600_PT0_SX970_V1___-400x300.jpg	\N	\N	\N	\N	\N	\N
2	Badminton Shuttlecocks	2026-08-24 13:49:28.851-04	2026-08-24 13:49:28.152-04	https://cdn.larumsport.com/media/2026/08/dffacbcb-e013-4e07-9440-ad336df3b11f.__CR0%2C0%2C300%2C300_PT0_SX300_V1___.jpg	\N	https://cdn.larumsport.com/media/2026/08/dffacbcb-e013-4e07-9440-ad336df3b11f.__CR0,0,300,300_PT0_SX300_V1___.jpg	image/jpeg	30188	300	300	50	50	/api/media/file/2026%2F08%2Fdffacbcb-e013-4e07-9440-ad336df3b11f.__CR0%2C0%2C300%2C300_PT0_SX300_V1___-400x300.jpg	400	300	image/jpeg	15920	2026/08/dffacbcb-e013-4e07-9440-ad336df3b11f.__CR0,0,300,300_PT0_SX300_V1___-400x300.jpg	\N	\N	\N	\N	\N	\N
4	Badminton Shuttlecocks	2026-08-25 03:42:40.908-04	2026-08-25 03:42:16.838-04	https://cdn.larumsport.com/media/2026/08/e283aa06-c31b-46ff-96a3-ea1a6e58af2d.jpg	\N	https://cdn.larumsport.com/media/2026/08/e283aa06-c31b-46ff-96a3-ea1a6e58af2d.jpg	image/jpeg	34021	300	300	50	50	/api/media/file/2026%2F08%2Fe283aa06-c31b-46ff-96a3-ea1a6e58af2d-400x300.jpg	400	300	image/jpeg	16766	2026/08/e283aa06-c31b-46ff-96a3-ea1a6e58af2d-400x300.jpg	\N	\N	\N	\N	\N	\N
3	Badminton Shuttlecocks	2026-08-24 13:59:13.874-04	2026-08-24 13:59:13.78-04	https://cdn.larumsport.com/media/2026/08/fc0a72bd-e592-40ab-86aa-ae77f4407eef.__CR0%2C0%2C300%2C300_PT0_SX300_V1___.jpg	\N	https://cdn.larumsport.com/media/2026/08/fc0a72bd-e592-40ab-86aa-ae77f4407eef.__CR0,0,300,300_PT0_SX300_V1___.jpg	image/jpeg	35081	300	300	50	50	/api/media/file/2026%2F08%2Ffc0a72bd-e592-40ab-86aa-ae77f4407eef.__CR0%2C0%2C300%2C300_PT0_SX300_V1___-400x300.jpg	400	300	image/jpeg	19000	2026/08/fc0a72bd-e592-40ab-86aa-ae77f4407eef.__CR0,0,300,300_PT0_SX300_V1___-400x300.jpg	\N	\N	\N	\N	\N	\N
5	Badminton Shuttlecocks	2026-08-25 03:42:56.789-04	2026-08-25 03:42:56.733-04	https://cdn.larumsport.com/media/2026/08/66ac7de8-0669-4d9b-a8ae-8e1a7d0e69fe.jpg	\N	https://cdn.larumsport.com/media/2026/08/66ac7de8-0669-4d9b-a8ae-8e1a7d0e69fe.jpg	image/jpeg	33563	300	300	50	50	/api/media/file/2026%2F08%2F66ac7de8-0669-4d9b-a8ae-8e1a7d0e69fe-400x300.jpg	400	300	image/jpeg	20589	2026/08/66ac7de8-0669-4d9b-a8ae-8e1a7d0e69fe-400x300.jpg	\N	\N	\N	\N	\N	\N
6	Badminton Shuttlecocks	2026-08-25 03:43:09.316-04	2026-08-25 03:43:09.295-04	https://cdn.larumsport.com/media/2026/08/Fe269d31c-67ff-400b-9ed1-276393f61e07.jpg	\N	https://cdn.larumsport.com/media/2026/08/e269d31c-67ff-400b-9ed1-276393f61e07.jpg	image/jpeg	39327	300	300	50	50	/api/media/file/2026%2F08%2Fe269d31c-67ff-400b-9ed1-276393f61e07-400x300.jpg	400	300	image/jpeg	22058	2026/08/e269d31c-67ff-400b-9ed1-276393f61e07-400x300.jpg	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: online_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.online_images (id, title, image_url, description, alt, updated_at, created_at) FROM stdin;
2	Sport style with pace.TEST	https://www.cherrytennisco.com/cdn/shop/files/15-0Q3A4185.jpg?v=1753214369&width=1500	Sharp silhouettes and practical comfort for training days, travel days, and match days.	\N	2026-08-13 22:28:03.174-04	2026-08-13 10:37:53.495-04
1	Train hard. Move clean.	https://cdn.larumsport.com/s/files/0822/ebae989853824d63992723764146e552.jpg	Built for focused sessions, everyday recovery, and the quiet confidence between both.	\N	2026-08-22 05:45:41.424-04	2026-08-13 10:32:07.754-04
3	Badminton Shuttlecocks	https://cdn.larumsport.com/s/files/0822/d5457e934d504b15a846d3b4c27c9547.jpg	\N	Badminton Shuttlecocks	2026-08-22 05:49:21.491-04	2026-08-22 05:49:21.485-04
\.


--
-- Data for Name: payload_kv; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_kv (id, key, data) FROM stdin;
\.


--
-- Data for Name: payload_locked_documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_locked_documents (id, global_slug, updated_at, created_at) FROM stdin;
11	\N	2026-08-20 10:25:04.453-04	2026-08-20 10:25:04.45-04
26	\N	2026-08-25 03:42:40.891-04	2026-08-25 03:42:40.891-04
\.


--
-- Data for Name: payload_locked_documents_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_locked_documents_rels (id, "order", parent_id, path, users_id, media_id, product_enhancements_id, articles_id, online_images_id) FROM stdin;
21	\N	11	document	\N	\N	\N	1	\N
22	\N	11	user	1	\N	\N	\N	\N
51	\N	26	document	\N	4	\N	\N	\N
52	\N	26	user	1	\N	\N	\N	\N
\.


--
-- Data for Name: payload_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_migrations (id, name, batch, updated_at, created_at) FROM stdin;
1	dev	-1	2026-08-26 10:27:17.18-04	2026-08-12 04:15:18.237-04
\.


--
-- Data for Name: payload_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_preferences (id, key, value, updated_at, created_at) FROM stdin;
1	collection-users	{"limit": 10}	2026-08-13 03:59:17.373-04	2026-08-12 08:09:46.906-04
5	collection-articles	{"editViewType": "default"}	2026-08-13 07:22:58.523-04	2026-08-13 07:19:23.716-04
2	collection-media	{"limit": 10, "editViewType": "default"}	2026-08-13 08:53:53.304-04	2026-08-12 08:09:51.794-04
6	collection-online-images	{"limit": 10, "editViewType": "default"}	2026-08-13 10:32:07.996-04	2026-08-13 10:08:24.392-04
4	collection-product-enhancements	{"limit": 10, "editViewType": "default"}	2026-08-24 13:27:43.72-04	2026-08-12 08:09:54.572-04
7	collection-product-enhancements-1	{"fields": {"highlights": {"collapsed": ["6a8d4529c2d73f481932a4d6"]}, "story_sections": {"collapsed": ["6a8c855f5d16d826267671ea", "6a8c85d05d16d826267671ec"]}}}	2026-08-25 03:33:14.394-04	2026-08-24 11:42:52.92-04
3	nav	{"groups": {"内容": {"open": false}, "Medusa Enhancements": {"open": true}}}	2026-08-25 14:02:07.433-04	2026-08-12 08:09:53.6-04
\.


--
-- Data for Name: payload_preferences_rels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payload_preferences_rels (id, "order", parent_id, path, users_id) FROM stdin;
9	\N	1	user	1
14	\N	5	user	1
20	\N	2	user	1
24	\N	6	user	1
32	\N	4	user	1
34	\N	7	user	1
35	\N	3	user	1
\.


--
-- Data for Name: product_enhancements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_enhancements (id, status, medusa_product_id, medusa_product_handle, title, subtitle, hero_eyebrow, care_notes, video_url, seo_meta_title, seo_meta_description, seo_og_image_id, updated_at, created_at, content) FROM stdin;
1	published	prod_01KYD5RMS93JCQ1TJ282CV9M57	/us/products/t-shirt	12 PACK Badminton Shuttlecocks	\N	\N	\N	\N	\N	\N	\N	2026-08-25 03:43:11.661-04	2026-08-24 10:20:31.634-04	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"id": "6a8c79b8f9cf8abe9dc7b144", "type": "upload", "value": 1, "fields": null, "format": "center", "version": 3, "relationTo": "media"}, {"tag": "h3", "type": "heading", "format": "center", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "12 PACK Feather Shuttlecocks", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null}, {"type": "paragraph", "format": "start", "indent": 0, "version": 1, "children": [], "direction": null, "textStyle": "", "textFormat": 0}, {"tag": "ul", "type": "list", "start": 1, "format": "", "indent": 0, "version": 1, "children": [{"type": "listitem", "value": 1, "format": "start", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Badminton Birdies", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}], "direction": null}, {"type": "listitem", "value": 2, "format": "start", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Excellent flight stability", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}], "direction": null}, {"type": "listitem", "value": 3, "format": "start", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Suitable for recreational game play", "type": "text", "style": "", "detail": 0, "format": 1, "version": 1}], "direction": null}], "listType": "bullet", "direction": null, "textFormat": 1}, {"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}
2	published	prod_01KYD5RMSA6BYVJQ9HZRWA26RT	sweatpants	Badminton Shuttlecocks 12-Pack	\N	\N	\N	\N	\N	\N	\N	2026-08-25 13:22:36.703-04	2026-08-25 13:22:36.679-04	{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [{"mode": "normal", "text": "Experience smoother and more stable badminton play with our 12-Pack Feather Badminton Shuttlecocks—designed for players who value durability, speed, and consistent flight. Each shuttle is crafted with premium natural bird feathers and a reinforced thick shaft, ensuring excellent resilience and stability in every swing. Suitable for both indoor and outdoor courts, these shuttlecocks deliver fast, steady flight and long-lasting performance, making them perfect for training sessions, competitive matches, school sports, coaching, and family entertainment. Whether you're a beginner learning the basics or a trainer drilling daily practice, these shuttlecocks will help you play better and longer. Packaged in a protective tube to prevent damage in transit, you can rely on these shuttlecocks for continuous use. We also offer professional support and factory-direct bulk pricing, making them a smart choice for clubs, coaches, and sports teams. Upgrade your badminton experience — better flight, better durability, more fun.", "type": "text", "style": "", "detail": 0, "format": 0, "version": 1}], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}
\.


--
-- Data for Name: product_enhancements_highlights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_enhancements_highlights (_order, _parent_id, id, label, description) FROM stdin;
\.


--
-- Data for Name: product_enhancements_image_blocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_enhancements_image_blocks (_order, _parent_id, id, image_id, title, description) FROM stdin;
1	1	6a8d46a2c2d73f481932a4da	4	\N	\N
2	1	6a8d4776c2d73f481932a4dc	5	\N	\N
3	1	6a8d4781c2d73f481932a4de	6	\N	\N
\.


--
-- Data for Name: product_enhancements_specifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_enhancements_specifications (_order, _parent_id, id, label, value) FROM stdin;
\.


--
-- Data for Name: product_enhancements_story_sections; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.product_enhancements_story_sections (_order, _parent_id, id, heading, body, image_id, image_position) FROM stdin;
1	1	6a8c855f5d16d826267671ea	Durability & Stability	Premium birds feather and sturdy structure provide a continuously play and make the ball for long time use.\nThese shuttlecocks are very durable and will provide you with many hours of excellent badminton excitement\nPerfect for all your indoor and outdoor games for Primary level.	2	left
2	1	6a8c85d05d16d826267671ec	Premium and Cheap Badminton,Beautifully crafted	Our badminton brides are made of high quality birds feather with thick hair shaft .\nlightweight to provide smooth and even flight.\nThe feathers are straight and dense, with good strength, which enhances the resistance of badminton.	3	right
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, updated_at, created_at, email, reset_password_token, reset_password_expiration, salt, hash, login_attempts, lock_until) FROM stdin;
1	2026-08-12 04:36:01.306-04	2026-08-12 04:36:01.302-04	admin@example.com	\N	\N	67f8a7414b597d37bc233dc0208c3c63316548f4dee93a96dadd9776c82374a0	7abad5e0c1c847f8ab588312663b2a73b893b491514726f4bfed13f92d6258621cef8009e0710db4395d491d3d8e8a7c9c84ac813c1fd4efa2b4cb997bfe9a377ec5ecbd2767e625d44f81fb9644edd142b5853a8b53922e2d9acde62b6f845d983ed3095c19e9e60dcc4b554b027b403dc6681e61f8fddb5f87bda0bca04475bddd2ecedec007091f5234e80664840fd0f520b0d7d40cd4e157110346cbbf83272723817723fb3eb8709b6d7f69922e37bf6089c8c6014420334ff398c9f6dbfe08389bd2e7a8a82084cea35f7b55dcfa75a5af956247a0540d02dd4da6181562949ff027a025634f032d18ee02a6b33b6627e92a7a785d7325038629305f86b091139c1d665bdbf3912fe68f7aa2e0345390187624efb0eb337a7e298457819750a822e8f9d61096041c7f50ebd7a01a4b8fc50c83121308bddc083693eaf61e2e97e9a95941e07b7a5a02a46fab9dc7e2a2c87244aef1fe58d6578c4265e93da70c335d15e6c0bd52271eccc878cbbb449f7df7f1087398db65d291c0a8e67d9e7c0f0b9eefdbdc25a025685894a9373adc4355183fa3c55a05d910035da7a7e82a9290145053b160966455b198aa291da14604af65a7bf515a3a5b2f762ac0c35843b018bdfc0129b0c2688eab15ae9f3423174d2f24d40471e0cdc862c5af8e0eacf7e546bfb530906f523e9efb825fd6f6f8e169e48ae768c90a0ca092	0	\N
\.


--
-- Data for Name: users_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_sessions (_order, _parent_id, id, created_at, expires_at) FROM stdin;
1	1	a12bcfaa-d5c9-4e60-b30e-e6fbc600b86f	2026-08-30 11:47:30.005-04	2026-08-30 13:47:30.005-04
\.


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_id_seq', 3, true);


--
-- Name: articles_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_rels_id_seq', 1, false);


--
-- Name: media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.media_id_seq', 6, true);


--
-- Name: online_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.online_images_id_seq', 3, true);


--
-- Name: payload_kv_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_kv_id_seq', 1, false);


--
-- Name: payload_locked_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_locked_documents_id_seq', 26, true);


--
-- Name: payload_locked_documents_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_locked_documents_rels_id_seq', 52, true);


--
-- Name: payload_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_migrations_id_seq', 1, true);


--
-- Name: payload_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_preferences_id_seq', 7, true);


--
-- Name: payload_preferences_rels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payload_preferences_rels_id_seq', 35, true);


--
-- Name: product_enhancements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_enhancements_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles_rels articles_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles_rels
    ADD CONSTRAINT articles_rels_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: online_images online_images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.online_images
    ADD CONSTRAINT online_images_pkey PRIMARY KEY (id);


--
-- Name: payload_kv payload_kv_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_kv
    ADD CONSTRAINT payload_kv_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents payload_locked_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents
    ADD CONSTRAINT payload_locked_documents_pkey PRIMARY KEY (id);


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_pkey PRIMARY KEY (id);


--
-- Name: payload_migrations payload_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_migrations
    ADD CONSTRAINT payload_migrations_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences payload_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences
    ADD CONSTRAINT payload_preferences_pkey PRIMARY KEY (id);


--
-- Name: payload_preferences_rels payload_preferences_rels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_pkey PRIMARY KEY (id);


--
-- Name: product_enhancements_highlights product_enhancements_highlights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_highlights
    ADD CONSTRAINT product_enhancements_highlights_pkey PRIMARY KEY (id);


--
-- Name: product_enhancements_image_blocks product_enhancements_image_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_image_blocks
    ADD CONSTRAINT product_enhancements_image_blocks_pkey PRIMARY KEY (id);


--
-- Name: product_enhancements product_enhancements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements
    ADD CONSTRAINT product_enhancements_pkey PRIMARY KEY (id);


--
-- Name: product_enhancements_specifications product_enhancements_specifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_specifications
    ADD CONSTRAINT product_enhancements_specifications_pkey PRIMARY KEY (id);


--
-- Name: product_enhancements_story_sections product_enhancements_story_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_story_sections
    ADD CONSTRAINT product_enhancements_story_sections_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users_sessions users_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_pkey PRIMARY KEY (id);


--
-- Name: articles_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_created_at_idx ON public.articles USING btree (created_at);


--
-- Name: articles_hero_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_hero_image_idx ON public.articles USING btree (hero_image_id);


--
-- Name: articles_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_rels_order_idx ON public.articles_rels USING btree ("order");


--
-- Name: articles_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_rels_parent_idx ON public.articles_rels USING btree (parent_id);


--
-- Name: articles_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_rels_path_idx ON public.articles_rels USING btree (path);


--
-- Name: articles_rels_product_enhancements_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_rels_product_enhancements_id_idx ON public.articles_rels USING btree (product_enhancements_id);


--
-- Name: articles_seo_seo_og_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_seo_seo_og_image_idx ON public.articles USING btree (seo_og_image_id);


--
-- Name: articles_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX articles_slug_idx ON public.articles USING btree (slug);


--
-- Name: articles_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX articles_updated_at_idx ON public.articles USING btree (updated_at);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX media_filename_idx ON public.media USING btree (filename);


--
-- Name: media_sizes_product_story_sizes_product_story_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_product_story_sizes_product_story_filename_idx ON public.media USING btree (sizes_product_story_filename);


--
-- Name: media_sizes_thumbnail_sizes_thumbnail_filename_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_sizes_thumbnail_sizes_thumbnail_filename_idx ON public.media USING btree (sizes_thumbnail_filename);


--
-- Name: media_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX media_updated_at_idx ON public.media USING btree (updated_at);


--
-- Name: online_images_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX online_images_created_at_idx ON public.online_images USING btree (created_at);


--
-- Name: online_images_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX online_images_updated_at_idx ON public.online_images USING btree (updated_at);


--
-- Name: payload_kv_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX payload_kv_key_idx ON public.payload_kv USING btree (key);


--
-- Name: payload_locked_documents_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_created_at_idx ON public.payload_locked_documents USING btree (created_at);


--
-- Name: payload_locked_documents_global_slug_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_global_slug_idx ON public.payload_locked_documents USING btree (global_slug);


--
-- Name: payload_locked_documents_rels_articles_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_articles_id_idx ON public.payload_locked_documents_rels USING btree (articles_id);


--
-- Name: payload_locked_documents_rels_media_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_media_id_idx ON public.payload_locked_documents_rels USING btree (media_id);


--
-- Name: payload_locked_documents_rels_online_images_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_online_images_id_idx ON public.payload_locked_documents_rels USING btree (online_images_id);


--
-- Name: payload_locked_documents_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_order_idx ON public.payload_locked_documents_rels USING btree ("order");


--
-- Name: payload_locked_documents_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_parent_idx ON public.payload_locked_documents_rels USING btree (parent_id);


--
-- Name: payload_locked_documents_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_path_idx ON public.payload_locked_documents_rels USING btree (path);


--
-- Name: payload_locked_documents_rels_product_enhancements_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_product_enhancements_id_idx ON public.payload_locked_documents_rels USING btree (product_enhancements_id);


--
-- Name: payload_locked_documents_rels_users_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_rels_users_id_idx ON public.payload_locked_documents_rels USING btree (users_id);


--
-- Name: payload_locked_documents_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_locked_documents_updated_at_idx ON public.payload_locked_documents USING btree (updated_at);


--
-- Name: payload_migrations_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_migrations_created_at_idx ON public.payload_migrations USING btree (created_at);


--
-- Name: payload_migrations_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_migrations_updated_at_idx ON public.payload_migrations USING btree (updated_at);


--
-- Name: payload_preferences_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_created_at_idx ON public.payload_preferences USING btree (created_at);


--
-- Name: payload_preferences_key_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_key_idx ON public.payload_preferences USING btree (key);


--
-- Name: payload_preferences_rels_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_order_idx ON public.payload_preferences_rels USING btree ("order");


--
-- Name: payload_preferences_rels_parent_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_parent_idx ON public.payload_preferences_rels USING btree (parent_id);


--
-- Name: payload_preferences_rels_path_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_path_idx ON public.payload_preferences_rels USING btree (path);


--
-- Name: payload_preferences_rels_users_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_rels_users_id_idx ON public.payload_preferences_rels USING btree (users_id);


--
-- Name: payload_preferences_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX payload_preferences_updated_at_idx ON public.payload_preferences USING btree (updated_at);


--
-- Name: product_enhancements_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_created_at_idx ON public.product_enhancements USING btree (created_at);


--
-- Name: product_enhancements_highlights_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_highlights_order_idx ON public.product_enhancements_highlights USING btree (_order);


--
-- Name: product_enhancements_highlights_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_highlights_parent_id_idx ON public.product_enhancements_highlights USING btree (_parent_id);


--
-- Name: product_enhancements_image_blocks_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_image_blocks_image_idx ON public.product_enhancements_image_blocks USING btree (image_id);


--
-- Name: product_enhancements_image_blocks_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_image_blocks_order_idx ON public.product_enhancements_image_blocks USING btree (_order);


--
-- Name: product_enhancements_image_blocks_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_image_blocks_parent_id_idx ON public.product_enhancements_image_blocks USING btree (_parent_id);


--
-- Name: product_enhancements_medusa_product_handle_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_enhancements_medusa_product_handle_idx ON public.product_enhancements USING btree (medusa_product_handle);


--
-- Name: product_enhancements_medusa_product_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX product_enhancements_medusa_product_id_idx ON public.product_enhancements USING btree (medusa_product_id);


--
-- Name: product_enhancements_seo_seo_og_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_seo_seo_og_image_idx ON public.product_enhancements USING btree (seo_og_image_id);


--
-- Name: product_enhancements_specifications_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_specifications_order_idx ON public.product_enhancements_specifications USING btree (_order);


--
-- Name: product_enhancements_specifications_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_specifications_parent_id_idx ON public.product_enhancements_specifications USING btree (_parent_id);


--
-- Name: product_enhancements_story_sections_image_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_story_sections_image_idx ON public.product_enhancements_story_sections USING btree (image_id);


--
-- Name: product_enhancements_story_sections_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_story_sections_order_idx ON public.product_enhancements_story_sections USING btree (_order);


--
-- Name: product_enhancements_story_sections_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_story_sections_parent_id_idx ON public.product_enhancements_story_sections USING btree (_parent_id);


--
-- Name: product_enhancements_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX product_enhancements_updated_at_idx ON public.product_enhancements USING btree (updated_at);


--
-- Name: users_created_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_created_at_idx ON public.users USING btree (created_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_sessions_order_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_sessions_order_idx ON public.users_sessions USING btree (_order);


--
-- Name: users_sessions_parent_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_sessions_parent_id_idx ON public.users_sessions USING btree (_parent_id);


--
-- Name: users_updated_at_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_updated_at_idx ON public.users USING btree (updated_at);


--
-- Name: articles articles_hero_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_hero_image_id_media_id_fk FOREIGN KEY (hero_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: articles_rels articles_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles_rels
    ADD CONSTRAINT articles_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: articles_rels articles_rels_product_enhancements_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles_rels
    ADD CONSTRAINT articles_rels_product_enhancements_fk FOREIGN KEY (product_enhancements_id) REFERENCES public.product_enhancements(id) ON DELETE CASCADE;


--
-- Name: articles articles_seo_og_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_seo_og_image_id_media_id_fk FOREIGN KEY (seo_og_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_articles_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_articles_fk FOREIGN KEY (articles_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_media_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_media_fk FOREIGN KEY (media_id) REFERENCES public.media(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_online_images_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_online_images_fk FOREIGN KEY (online_images_id) REFERENCES public.online_images(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_locked_documents(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_product_enhancements_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_product_enhancements_fk FOREIGN KEY (product_enhancements_id) REFERENCES public.product_enhancements(id) ON DELETE CASCADE;


--
-- Name: payload_locked_documents_rels payload_locked_documents_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_locked_documents_rels
    ADD CONSTRAINT payload_locked_documents_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_parent_fk FOREIGN KEY (parent_id) REFERENCES public.payload_preferences(id) ON DELETE CASCADE;


--
-- Name: payload_preferences_rels payload_preferences_rels_users_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payload_preferences_rels
    ADD CONSTRAINT payload_preferences_rels_users_fk FOREIGN KEY (users_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_enhancements_highlights product_enhancements_highlights_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_highlights
    ADD CONSTRAINT product_enhancements_highlights_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.product_enhancements(id) ON DELETE CASCADE;


--
-- Name: product_enhancements_image_blocks product_enhancements_image_blocks_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_image_blocks
    ADD CONSTRAINT product_enhancements_image_blocks_image_id_media_id_fk FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: product_enhancements_image_blocks product_enhancements_image_blocks_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_image_blocks
    ADD CONSTRAINT product_enhancements_image_blocks_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.product_enhancements(id) ON DELETE CASCADE;


--
-- Name: product_enhancements product_enhancements_seo_og_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements
    ADD CONSTRAINT product_enhancements_seo_og_image_id_media_id_fk FOREIGN KEY (seo_og_image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: product_enhancements_specifications product_enhancements_specifications_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_specifications
    ADD CONSTRAINT product_enhancements_specifications_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.product_enhancements(id) ON DELETE CASCADE;


--
-- Name: product_enhancements_story_sections product_enhancements_story_sections_image_id_media_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_story_sections
    ADD CONSTRAINT product_enhancements_story_sections_image_id_media_id_fk FOREIGN KEY (image_id) REFERENCES public.media(id) ON DELETE SET NULL;


--
-- Name: product_enhancements_story_sections product_enhancements_story_sections_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_enhancements_story_sections
    ADD CONSTRAINT product_enhancements_story_sections_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.product_enhancements(id) ON DELETE CASCADE;


--
-- Name: users_sessions users_sessions_parent_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_sessions
    ADD CONSTRAINT users_sessions_parent_id_fk FOREIGN KEY (_parent_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO larumsport_cms;


--
-- Name: TABLE articles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.articles TO larumsport_cms;


--
-- Name: SEQUENCE articles_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.articles_id_seq TO larumsport_cms;


--
-- Name: TABLE articles_rels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.articles_rels TO larumsport_cms;


--
-- Name: SEQUENCE articles_rels_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.articles_rels_id_seq TO larumsport_cms;


--
-- Name: TABLE media; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.media TO larumsport_cms;


--
-- Name: SEQUENCE media_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.media_id_seq TO larumsport_cms;


--
-- Name: TABLE online_images; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.online_images TO larumsport_cms;


--
-- Name: SEQUENCE online_images_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.online_images_id_seq TO larumsport_cms;


--
-- Name: TABLE payload_kv; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payload_kv TO larumsport_cms;


--
-- Name: SEQUENCE payload_kv_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payload_kv_id_seq TO larumsport_cms;


--
-- Name: TABLE payload_locked_documents; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payload_locked_documents TO larumsport_cms;


--
-- Name: SEQUENCE payload_locked_documents_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payload_locked_documents_id_seq TO larumsport_cms;


--
-- Name: TABLE payload_locked_documents_rels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payload_locked_documents_rels TO larumsport_cms;


--
-- Name: SEQUENCE payload_locked_documents_rels_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payload_locked_documents_rels_id_seq TO larumsport_cms;


--
-- Name: TABLE payload_migrations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payload_migrations TO larumsport_cms;


--
-- Name: SEQUENCE payload_migrations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payload_migrations_id_seq TO larumsport_cms;


--
-- Name: TABLE payload_preferences; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payload_preferences TO larumsport_cms;


--
-- Name: SEQUENCE payload_preferences_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payload_preferences_id_seq TO larumsport_cms;


--
-- Name: TABLE payload_preferences_rels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.payload_preferences_rels TO larumsport_cms;


--
-- Name: SEQUENCE payload_preferences_rels_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.payload_preferences_rels_id_seq TO larumsport_cms;


--
-- Name: TABLE product_enhancements; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_enhancements TO larumsport_cms;


--
-- Name: TABLE product_enhancements_highlights; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_enhancements_highlights TO larumsport_cms;


--
-- Name: SEQUENCE product_enhancements_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.product_enhancements_id_seq TO larumsport_cms;


--
-- Name: TABLE product_enhancements_image_blocks; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_enhancements_image_blocks TO larumsport_cms;


--
-- Name: TABLE product_enhancements_specifications; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_enhancements_specifications TO larumsport_cms;


--
-- Name: TABLE product_enhancements_story_sections; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.product_enhancements_story_sections TO larumsport_cms;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users TO larumsport_cms;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE public.users_id_seq TO larumsport_cms;


--
-- Name: TABLE users_sessions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.users_sessions TO larumsport_cms;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO larumsport_cms;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT ON TABLES TO larumsport_cms;


--
-- PostgreSQL database dump complete
--

\unrestrict navkdlxEfgIhZcDjBJ1lgHUDBzky7B6f5k9vm3nXc9qN2jq7ecMlyw3Z5iOZaQO

